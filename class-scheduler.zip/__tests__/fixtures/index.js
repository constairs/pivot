export const userData = {
  avatar_url: 'http://immedilet-invest.com/wp-content/uploads/2016/01/user-placeholder.jpg',
  email: 'example@trainwithpivot.com',
  first_name: 'Example',
  id: '5aa214c9-8f44-425f-b82a-e6de17ca81e9',
  last_name: 'Example',
  username: 'Example'
};


export const classCreateResponse = {
  data: {
    end_time: null,
    id: '74c5ff62-a10e-4a56-b7d1-0a399dba87c2',
    instructor: null,
    media: [],
    start_time: null,
    title: '30 Minute Core Workout',
    workout_plan_id: null
  }
};
