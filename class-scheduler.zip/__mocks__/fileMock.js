module.exports = 'file-stub';
